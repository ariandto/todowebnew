var message = "alhamdulillah"

function openForm() {
    document.getElementById("container-todo").style.display = "block";
    document.getElementById("table-todo").style.display = "none";
}


function closeForm() {
    document.getElementById("container-todo").style.display = "none";
    document.getElementById("table-todo").style.display = "block";
}


